package iss.java.mail;





import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

public class Main2014302580260 implements IMailService{
private final transient Properties props = System.getProperties();
private transient MailAuthenticator authenticator;
private transient Session session;
private final String username="13476183363@163.com";
private final String password="sdqamiyoxzvooawg";
private final String SmtpHostName="smtp.163.com";
@Override
public void connect() throws MessagingException {
	// TODO Auto-generated method stub
	props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.host", SmtpHostName);
    // 验证
    authenticator = new MailAuthenticator(username, password);
    // 创建session
    session = Session.getInstance(props, authenticator);
}


@Override
public void send(String recipient, String subject, Object content)
		throws MessagingException {
	// TODO Auto-generated method stub
	final MimeMessage message = new MimeMessage(session);
    // 设置发信人
    message.setFrom(new InternetAddress(authenticator.getUsername()));
    // 设置收件人
    message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
    // 设置主题
    message.setSubject(subject);
    // 设置邮件内容
    message.setContent(content.toString(), "text/html;charset=utf-8");
    // 发送
    Transport.send(message);
}

@Override
public boolean listen() throws MessagingException {
	// TODO Auto-generated method stub
	//准备连接服务器的会话信息
	Properties props=new Properties();
	props.setProperty("mail.store.protocol", "imap");
	props.setProperty("mail.imap.host","imap.163.com");
	props.setProperty("mail.imap.port","143");
	//创建session实例对象
	Session session=Session.getInstance(props);
    //创建IMAP协议的STORE对象
	Store store=session.getStore("imap");
	//连接邮件服务器
	store.connect("13476183363@163.com","sdqamiyoxzvooawg");
	//获得收件箱
	Folder folder=store.getFolder("INBOX");
	//以读写模式打开收件箱
	folder.open(Folder.READ_WRITE);
	//获得邮件列表
	if(folder.getNewMessageCount()>0){
		System.out.println("收件箱中共" + folder.getNewMessageCount() + "封新邮件!");
		return true;
	}
	else{
		return false;
	}
}

@Override
public String getReplyMessageContent(String sender, String subject)
		throws MessagingException, IOException {
	// TODO Auto-generated method stub
	String imapserver="imap.163.com";//邮件服务器
	String username="13476183363@163.com";
	String password="sdqamiyoxzvooawg";
	String word="自动回复";
	Properties props=new Properties();
	props.put("mail.imap.host",imapserver);
	props.put("mail.imap.auth.plain.disable","true");
	Session session=Session.getInstance(props,null);
	session.setDebug(false);//不采用DEBUG模式
	IMAPFolder folder=null;
	IMAPStore store=null;
	store=(IMAPStore)session.getStore("imap");
    store.connect(imapserver,username,password);
    folder=(IMAPFolder)store.getFolder("INBOX");
    folder.open(Folder.READ_WRITE);
    Message[]messages=folder.getMessages();
    for(int i=0;i<folder.getMessageCount();i++){
    Pattern pattern=Pattern.compile(word);
    Matcher m=pattern.matcher(messages[i].getSubject());
    if(m.find()){
    	System.out.println("自动回复收到");
    	break;
    }
    }
	return null;
}
}
